<?php
// Подключение к базе данных (AMPPS)
$conn = new mysqli("localhost", "root", "new123", "spa-center");

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}
?>